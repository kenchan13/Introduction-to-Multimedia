Open the file q3 and run it
Every image and diagram will be generated.